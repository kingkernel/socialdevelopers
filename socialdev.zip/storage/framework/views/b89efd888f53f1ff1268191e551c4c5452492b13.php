<?php
$meses = [
    1=>"Janeiro",
    2=>"Fevereiro",
    3=>"Março",
    4=>"Abril",
    5=>"Maio",
    6=>"Junho",
    7=>"Julho",
    8=>"Agosto",
    9=>"Setembro",
    10=>"Outubro",
    11=>"Novembro",
    12=>"Dezembro"
];
?>

<?php $__env->startSection("bodymain"); ?>
<div class="container">
  <div class="container px-4 py-5" id="custom-cards">
    <h2 class="pb-2 border-bottom">Participe!</h2>
    <div class="row">
      <div class="col-md-4">
        <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" style="background-image: url('unsplash-photo-1.jpg');">
          <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1">
            <h4 class="pt-5 mt-5 mb-4 display-8 lh-1 fw-bold">De <b>Programadores</b> para<br/> <i>Programadores</i></h4>
            <ul class="d-flex list-unstyled mt-auto">
              <li class="me-auto">
                <img src="https://github.com/twbs.png" alt="Bootstrap" width="32" height="32" class="rounded-circle border border-white">
              </li>
              <li class="d-flex align-items-center me-3">
                <svg class="bi me-2" width="1em" height="1em"><use xlink:href="#geo-fill"></use></svg>
                <small>Earth</small>
              </li>
              <li class="d-flex align-items-center">
                <svg class="bi me-2" width="1em" height="1em"><use xlink:href="#calendar3"></use></svg>
                <small>3d</small>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col">
        <form action="http://<?php echo e($_SERVER["HTTP_HOST"]); ?>/newuserinput" method="POST">
          <?php echo csrf_field(); ?>
          <div class="mb-3 row">
            <label for="staticEmail" class="col-sm-2 col-form-label">Email :</label>
            <div class="col-sm-10">
              <input type="email" class="form-control" name="email">
            </div>
          </div>
          <div class="mb-3 row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Password :</label>
            <div class="col-sm-10">
              <input type="password" class="form-control" name="passkey">
            </div>
          </div>
          <div class="mb-3 row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Nome :</label>
            <div class="col-sm-3">
              <input type="text" class="form-control" name="name">
            </div>
            <label for="inputPassword" class="col-sm-2 col-form-label">Sobrenome :</label>
            <div class="col-sm-5">
              <input type="text" class="form-control" name="fullname">
            </div>
          </div>
          <div class="mb-2 row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Ano :</label>
            <div class="col-sm-3">
              <select class="form-select" name="ano_c" require>
                <?php for($y = (intval(date("Y"))-100); $y <= intval(date("Y")); $y++): ?>
                    <option value="<?php echo e($y); ?>"><?php echo e($y); ?></option>
                <?php endfor; ?>
            </select>
            </div>
              <label for="inputPassword" class="col-sm-1 col-form-label">Mês:</label>
              <div class="col-sm-3">
                <select class="form-select" name="mes_c" require>
                  <?php for($m = 1; $m <= 12; $m++): ?>
                      <option value="<?php echo e($m); ?>"><?php echo e($meses[$m]); ?></option>
                  <?php endfor; ?>
              </select>
              </div>
              <label for="inputPassword" class="col-sm-1 col-form-label">Dia :</label>
              <div class="col-sm-2">
                <select class="form-select" name="dia_c" require>
                  <?php for($i = 1; $i <= 31; $i++): ?>
                      <?php if(strlen($i) < 2): ?>
                          <option value="<?php echo e($i); ?>"><?php echo e('0'.$i); ?></option>
                          <?php else: ?>
                          <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                      <?php endif; ?>
                  <?php endfor; ?>
              </select>
              </div>
          </div>
          <div class="mb-2 row">
            <div class="offset-md-2">
              <input type="submit" value="Cadastrar" class="btn btn-primary">
            </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("bootstrap.model", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\socialdev\resources\views/bootstrap/input_newuser.blade.php ENDPATH**/ ?>